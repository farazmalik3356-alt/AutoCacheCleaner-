package com.autocachecleaner;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.IBinder;
import android.provider.Settings;
import android.widget.Toast;

public class CacheCleanerService extends Service {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences prefs = getSharedPreferences(CleanerState.PREFS, MODE_PRIVATE);
        String[] queue = getQueue(prefs);
        int index = prefs.getInt(CleanerState.KEY_INDEX, 0);

        if (!prefs.getBoolean(CleanerState.KEY_RUNNING, false) || index >= queue.length) {
            prefs.edit().putBoolean(CleanerState.KEY_RUNNING, false).apply();
            Toast.makeText(this, R.string.cache_cleaner_finished, Toast.LENGTH_SHORT).show();
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        openAppSettings(queue[index]);
        Toast.makeText(this, R.string.cache_cleaner_started, Toast.LENGTH_SHORT).show();
        stopSelf(startId);
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private String[] getQueue(SharedPreferences prefs) {
        String queue = prefs.getString(CleanerState.KEY_QUEUE, "");
        if (queue.trim().isEmpty()) {
            return new String[0];
        }
        return queue.split("\\n");
    }

    private void openAppSettings(String packageName) {
        Intent settingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        settingsIntent.setData(Uri.parse("package:" + packageName));
        settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(settingsIntent);
    }
}
