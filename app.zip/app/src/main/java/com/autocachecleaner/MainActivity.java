package com.autocachecleaner;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private final List<AppInfo> apps = new ArrayList<>();
    private AppAdapter adapter;
    private TextView subtitle;
    private TextView progressText;
    private Button startButton;
    private Button stopButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = new AppAdapter();
        ListView appList = findViewById(R.id.appList);
        appList.setAdapter(adapter);

        subtitle = findViewById(R.id.subtitle);

        Button accessibilityButton = findViewById(R.id.accessibilityButton);
        accessibilityButton.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(v -> startCleaner());

        stopButton = findViewById(R.id.stopButton);
        stopButton.setOnClickListener(v -> stopCleaner());

        progressText = findViewById(R.id.progressText);

        loadInstalledApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (subtitle != null) {
            subtitle.setText(isAccessibilityEnabled()
                    ? R.string.subtitle_ready
                    : R.string.subtitle_enable_accessibility);
        }
        updateProgressUi();
    }

    private void loadInstalledApps() {
        PackageManager packageManager = getPackageManager();
        List<ApplicationInfo> installedApps =
                packageManager.getInstalledApplications(PackageManager.GET_META_DATA);

        apps.clear();
        for (ApplicationInfo info : installedApps) {
            if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                apps.add(new AppInfo(
                        packageManager.getApplicationLabel(info).toString(),
                        info.packageName,
                        packageManager.getApplicationIcon(info)
                ));
            }
        }

        Collections.sort(apps, (left, right) ->
                left.getAppName().compareToIgnoreCase(right.getAppName()));
        adapter.notifyDataSetChanged();
    }

    private void startCleaner() {
        if (!isAccessibilityEnabled()) {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        if (apps.isEmpty()) {
            loadInstalledApps();
        }

        StringBuilder queue = new StringBuilder();
        for (AppInfo app : apps) {
            if (queue.length() > 0) {
                queue.append('\n');
            }
            queue.append(app.getPackageName());
        }

        SharedPreferences prefs = getSharedPreferences(CleanerState.PREFS, MODE_PRIVATE);
        prefs.edit()
                .putBoolean(CleanerState.KEY_RUNNING, true)
                .putString(CleanerState.KEY_QUEUE, queue.toString())
                .putInt(CleanerState.KEY_INDEX, 0)
                .putInt(CleanerState.KEY_PHASE, CleanerState.PHASE_APP_INFO)
                .putInt(CleanerState.KEY_ATTEMPTS, 0)
                .apply();

        startService(new Intent(this, CacheCleanerService.class));
        updateProgressUi();
    }

    private void stopCleaner() {
        getSharedPreferences(CleanerState.PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(CleanerState.KEY_RUNNING, false)
                .apply();
        updateProgressUi();
    }

    private void updateProgressUi() {
        if (progressText == null || startButton == null || stopButton == null) {
            return;
        }

        SharedPreferences prefs = getSharedPreferences(CleanerState.PREFS, MODE_PRIVATE);
        boolean running = prefs.getBoolean(CleanerState.KEY_RUNNING, false);
        String[] queue = getQueue(prefs);
        int index = prefs.getInt(CleanerState.KEY_INDEX, 0);

        if (running && queue.length > 0) {
            int current = Math.min(index + 1, queue.length);
            progressText.setText(getString(R.string.progress_cleaning, current, queue.length));
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            return;
        }

        progressText.setText(R.string.progress_idle);
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
    }

    private String[] getQueue(SharedPreferences prefs) {
        String queue = prefs.getString(CleanerState.KEY_QUEUE, "");
        if (queue.trim().isEmpty()) {
            return new String[0];
        }
        return queue.split("\\n");
    }

    private boolean isAccessibilityEnabled() {
        ComponentName service = new ComponentName(this, AccessibilityService.class);
        String enabledServices = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );

        if (TextUtils.isEmpty(enabledServices)) {
            return false;
        }

        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabledServices);
        while (splitter.hasNext()) {
            ComponentName enabledService = ComponentName.unflattenFromString(splitter.next());
            if (service.equals(enabledService)) {
                return true;
            }
        }

        return false;
    }

    private class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return apps.size();
        }

        @Override
        public AppInfo getItem(int position) {
            return apps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_app, parent, false);
            }

            AppInfo app = getItem(position);
            ImageView icon = view.findViewById(R.id.appIcon);
            TextView name = view.findViewById(R.id.appName);
            TextView packageName = view.findViewById(R.id.packageName);

            icon.setImageDrawable(app.getIcon());
            name.setText(app.getAppName());
            packageName.setText(app.getPackageName());

            return view;
        }
    }
}
