package com.autocachecleaner;

final class CleanerState {
    static final String PREFS = "cleaner_state";
    static final String KEY_RUNNING = "running";
    static final String KEY_QUEUE = "queue";
    static final String KEY_INDEX = "index";
    static final String KEY_PHASE = "phase";
    static final String KEY_ATTEMPTS = "attempts";

    static final int PHASE_APP_INFO = 0;
    static final int PHASE_STORAGE = 1;

    private CleanerState() {
    }
}
