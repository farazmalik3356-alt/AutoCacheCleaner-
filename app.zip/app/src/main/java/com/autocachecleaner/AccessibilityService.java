package com.autocachecleaner;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

public class AccessibilityService extends android.accessibilityservice.AccessibilityService {
    private static final int MAX_ATTEMPTS_PER_PHASE = 6;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean stepScheduled;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        scheduleStep(500);
    }

    @Override
    public void onInterrupt() {
    }

    private void scheduleStep(long delayMillis) {
        if (stepScheduled) {
            return;
        }

        stepScheduled = true;
        handler.postDelayed(() -> {
            stepScheduled = false;
            runCleanerStep();
        }, delayMillis);
    }

    private void runCleanerStep() {
        SharedPreferences prefs = getSharedPreferences(CleanerState.PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean(CleanerState.KEY_RUNNING, false)) {
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            scheduleStep(700);
            return;
        }

        int phase = prefs.getInt(CleanerState.KEY_PHASE, CleanerState.PHASE_APP_INFO);
        boolean clicked = phase == CleanerState.PHASE_APP_INFO
                ? clickStorageEntry(root)
                : clickClearCache(root);

        if (clicked) {
            if (phase == CleanerState.PHASE_APP_INFO) {
                prefs.edit()
                        .putInt(CleanerState.KEY_PHASE, CleanerState.PHASE_STORAGE)
                        .putInt(CleanerState.KEY_ATTEMPTS, 0)
                        .apply();
                scheduleStep(900);
            } else {
                finishCurrentApp(prefs, 900);
            }
            return;
        }

        int attempts = prefs.getInt(CleanerState.KEY_ATTEMPTS, 0) + 1;
        if (attempts >= MAX_ATTEMPTS_PER_PHASE) {
            finishCurrentApp(prefs, 400);
            return;
        }

        prefs.edit().putInt(CleanerState.KEY_ATTEMPTS, attempts).apply();
        scheduleStep(700);
    }

    private boolean clickStorageEntry(AccessibilityNodeInfo root) {
        String[] labels = {
                "Storage & cache",
                "Storage and cache",
                "Storage",
                "Memory"
        };
        return clickFirstMatching(root, labels, false);
    }

    private boolean clickClearCache(AccessibilityNodeInfo root) {
        String[] labels = {
                "Clear cache",
                "CLEAR CACHE"
        };
        return clickFirstMatching(root, labels, true);
    }

    private boolean clickFirstMatching(
            AccessibilityNodeInfo root,
            String[] labels,
            boolean exactOnly
    ) {
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collectMatchingNodes(root, labels, exactOnly, nodes);

        for (AccessibilityNodeInfo node : nodes) {
            AccessibilityNodeInfo clickable = findClickableNode(node);
            if (clickable != null && clickable.isEnabled()) {
                return clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
        }

        return false;
    }

    private void collectMatchingNodes(
            AccessibilityNodeInfo node,
            String[] labels,
            boolean exactOnly,
            List<AccessibilityNodeInfo> matches
    ) {
        if (node == null) {
            return;
        }

        CharSequence text = node.getText();
        CharSequence description = node.getContentDescription();
        if (matchesLabel(text, labels, exactOnly) || matchesLabel(description, labels, exactOnly)) {
            matches.add(node);
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            collectMatchingNodes(node.getChild(i), labels, exactOnly, matches);
        }
    }

    private boolean matchesLabel(CharSequence value, String[] labels, boolean exactOnly) {
        if (value == null) {
            return false;
        }

        String normalized = value.toString().trim().toLowerCase();
        for (String label : labels) {
            String expected = label.toLowerCase();
            if (exactOnly ? normalized.equals(expected) : normalized.contains(expected)) {
                return true;
            }
        }
        return false;
    }

    private AccessibilityNodeInfo findClickableNode(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        while (current != null) {
            if (current.isClickable()) {
                return current;
            }
            current = current.getParent();
        }
        return null;
    }

    private void finishCurrentApp(SharedPreferences prefs, long delayMillis) {
        int nextIndex = prefs.getInt(CleanerState.KEY_INDEX, 0) + 1;
        String[] queue = getQueue(prefs);

        prefs.edit()
                .putInt(CleanerState.KEY_INDEX, nextIndex)
                .putInt(CleanerState.KEY_PHASE, CleanerState.PHASE_APP_INFO)
                .putInt(CleanerState.KEY_ATTEMPTS, 0)
                .apply();

        if (nextIndex >= queue.length) {
            prefs.edit().putBoolean(CleanerState.KEY_RUNNING, false).apply();
            performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }

        handler.postDelayed(() -> {
            SharedPreferences latestPrefs = getSharedPreferences(CleanerState.PREFS, MODE_PRIVATE);
            if (latestPrefs.getBoolean(CleanerState.KEY_RUNNING, false)) {
                openAppSettings(queue[nextIndex]);
            }
        }, delayMillis);
    }

    private String[] getQueue(SharedPreferences prefs) {
        String queue = prefs.getString(CleanerState.KEY_QUEUE, "");
        if (queue.trim().isEmpty()) {
            return new String[0];
        }
        return queue.split("\\n");
    }

    private void openAppSettings(String packageName) {
        Intent settingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        settingsIntent.setData(Uri.parse("package:" + packageName));
        settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(settingsIntent);
    }
}
